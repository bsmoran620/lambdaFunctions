from __future__ import print_function
import boto3
import os
import sys
import ftplib
import gzip
import paramiko

host = os.environ['HOSTNAME']
port = 22
username = os.environ['USERNAME']
password = os.environ['PASSWORD']
remote_directory = os.environ['DIR']

s3_client = boto3.client('s3')

def SFTPTransfer(localPath, pathForUpload):
    #If we don't change the current working directory to /tmp/, while doing the FTP, LAMBDA tries to create the file
    #in the /tmp folder in the host as well - if we give download_path as the filename in storlines function.
    print("ATTEMPTING SFTP TRANSFER")
    #os.chdir("/tmp/")
    #ftp = ftplib.FTP(host)
    #ftp.login(username, password)
    #print(ftp.getwelcome())
    transport = paramiko.Transport((host,port))
    transport.connect(None,username,password)
    sftp = paramiko.SFTPClient.from_transport(transport)
    print("Connected to SFTP successfully")

    #Based on the Host FTP server, change the following statement to True or False        
    #ftp.set_pasv(True)
    #print('FTP set to Passive Mode')
    #Change the working directory in the host
    #ftp.cwd(remote_directory)
    #print('Working directory in host changed to {}'.format(remote_directory))
    #Initiate File transfer     
    #Assumption is that the input file will always be a text file. In case if the file is other than text
    #use the following commented statements
    #file = open(pathForUpload,"rb")
    #ftp.storbinary('STOR ' + pathForUpload, file)
    #    file = open(sourcekey,"r")
    #    ftp.storlines('STOR ' + sourcekey, file)
    

    # Upload
    #filepath = "/home/foo.jpg"
    #localpath = "/home/pony.jpg"
    sftp.put(localPath, remote_directory + '/' + pathForUpload)

    print('File transmitted!!!')
    # Close
    if sftp: sftp.close()
    if transport: transport.close()
    

def lambda_handler(event, context):
    print("STARTING")
    for record in event['Records']:
        print(record)
        sourcebucket = record['s3']['bucket']['name']
        sourcekey = record['s3']['object']['key'] 

        #Download the file to /tmp/ folder        
        download_path = f"/tmp/{sourcekey.split('/')[1]}"
        print("ATTEMPTING TO DOWNLOAD: " + download_path)
        s3_client.download_file(sourcebucket, sourcekey, download_path)
        
        print("FILE DOWNLOADED " + download_path)
        
        #with zipfile.ZipFile(download_path, 'r') as zip_ref:
        #    zip_ref.extractall('/tmp/extract')
        #with gzip.GzipFile(fileobj=download_path, mode='rb') as fcontent:
        #    FTPTransfer(fcontent)
        outputPath = os.path.splitext(download_path)[0]
        print("ATTEMPTING TO OUTPUT TO " + outputPath)
        try:
            with open(outputPath, 'wb') as f_out, gzip.open(download_path, 'rb') as f_in:
                print("IN HERE")
                f_out.writelines(f_in)
                print("FILE CREATED")

                pathForUpload = remove_prefix(outputPath, "/tmp/")
                SFTPTransfer(outputPath, pathForUpload)
                print("SFTP COMPLETED")
        except Exception as e:
            print(e)
            
        return

def remove_prefix(text, prefix):
    if text.startswith(prefix):
        return text[len(prefix):]
    return text  # or whatever

def getResponse(statusCode, bodyText):
    return {
        'statusCode': statusCode,
        'body': json.dumps(bodyText),
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': 'https://getpowerpay.com',
            'Access-Control-Allow-Methods': 'OPTIONS,POST'
        }
    }